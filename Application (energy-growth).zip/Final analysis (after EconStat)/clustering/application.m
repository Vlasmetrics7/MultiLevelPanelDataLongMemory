
function R=application

[auxR1_EPCC,~,~]=R1;
[auxR2_EPCC,~,~]=R2;
[auxR3_EPCC,~,~]=R3;
[auxR4_EPCC,~,~]=R4;

R1_EPCC2=log(auxR1_EPCC);
R2_EPCC2=log(auxR2_EPCC);
R3_EPCC2=log(auxR3_EPCC);
R4_EPCC2=log(auxR4_EPCC);

%%%%%%%%%%% GCP EPCC GCF %%%%%%%%%%%%%%%%%%%%

R1_EPCC=R1_EPCC2(:,[1:2,5:8,10:14,17,19:20,22:24]);
R2_EPCC=R2_EPCC2(:,[1:12,14:19]);
R3_EPCC=R3_EPCC2(:,[1:3,5,7,9,11:13,15:19]);
R4_EPCC=R4_EPCC2(:,[1:6,8:13,15:17,19:23]);

y=[R1_EPCC,R2_EPCC,R3_EPCC,R4_EPCC]; 

Zdata= diff(y);

[T,NN]=size(Zdata);
%%%%%%%%%%%%%%%%%%
%LAG SELECTION

% XLag univariate selection
Pmax = 5; Criterio = 'AIC';
KU = KUnivariateSelection(Zdata, Pmax, Criterio);
% XLag factorial selection.
KL = KFactorialSelection(Zdata, Pmax, Criterio);
% XLag regression selection.
if KU > KL
    XLag = KSelection(Zdata, Pmax, Criterio, KL, KU);
else
    XLag = KU;
end

%%%%%%%%%%%%%%%%%%

% Distances calculation.
DistanceVector = zeros(NN*(NN-1)/2, 1);
k = 1;
for i = 1:NN
    for j = i+1:NN
        DistanceVector(k,1) = GCCmeasure(Zdata(:,i), Zdata(:,j), XLag);
        k = k + 1;
    end
end

L = linkage(real(DistanceVector(:,1))', 'ward');

label_co=[{'Australia',
'Bangladesh',
'Hong Kong',
'India',
'Indonesia',
'Iran',
'Israel',
'Japan',
'Jordan',
'Korea',
'Malaysia',
'New Zealand',
'Pakistan',
'Philippines',
'Singapore',
'Sri Lanka',
'Thailand',
'United Kingdom',
'Austria',
'Belgium',
'Denmark',
'Finland',
'France',
'Germany',
'Greece',
'Iceland',
'Ireland',
'Italy',
'Luxembourg',
'Netherlands',
'Norway',
'Portugal',
'Spain',
'Sweden',
'Switzerland',
'Algeria',
'Benin',
'Cameroon',
'Congo',
'Egypt',
'Gabon',
'Kenya',
'Mauritius',
'Morocco',
'Senegal',
'South Africa',
'Sudan',
'Togo',
'Tunisia',
'Argentina',
'Bolivia',
'Brazil',
'Canada',
'Chile',
'Colombia',
'Cuba',
'Dominican Rep.',
'Ecuador',
'El Salvador',
'Guatemala',
'Honduras',
'Mexico',
'Nicaragua',
'Panama',
'Peru',
'Trin. Tob',
'United States',
'Uruguay',
'Venezuela'
}];

H =dendrogram(L, 0,'ColorThreshold','default','Labels',label_co);
set(H,'LineWidth',3)


Xclusters = cluster(L, 'maxclust', 1:10);
R = GAPdistance(DistanceVector(:,1)', Xclusters, 150)

