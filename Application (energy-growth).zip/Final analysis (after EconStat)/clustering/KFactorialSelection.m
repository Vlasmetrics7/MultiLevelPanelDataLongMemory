% Factorial based selection of  K and K2 (not used in the paper).

function [R1, R2] = KFactorialSelection(Zdata, Pmax, Criterio)

[nc nr] = size(Zdata');

k0 = 5;
kmax = min(Pmax, nc);
toplot = 0;
twostep = 0;

nfactors = LamYaoProcedure(Zdata, k0, kmax, toplot, twostep);

% Estimation of a factorial model by PCA.
a = mean(Zdata);
[u,s,v] = svd(Zdata - ones(nr,1)*a);
k = zeros(nr, nfactors);
b = zeros(nc, nfactors);
r = zeros(nr, nc, nfactors);
for i = 1:nfactors
    k(:,i) = u(:,i)*s(i,i)*sum(v(:,i)); % Factors.
    b(:,i) = v(:,i)/sum(v(:,i)); % Weights.
end

Pselected = 0;
P2selected = 0;
for i = 1:nfactors
    [Psel, Resid] = ARselect(k(:,i), Pmax, Criterio);
    Pselected = max(Pselected, Psel);
    Rdata = Resid.^2;
    Psel = ARselect(Rdata, Pmax, Criterio);
    P2selected = max(P2selected, Psel);
end

R1 = Pselected;
R2 = P2selected;
