function R = GAPdistance(DistanceVector, Clusters, B)

[N, K] = size(Clusters);

% Within dispersion measures at the observed data.
W = WithinDispersion(DistanceVector, Clusters, K);

% Multidimensional scaling.
[Xmatrix, EigenValues] = cmdscale(DistanceVector);

F = sum(EigenValues > eps^(1/4))

Xmatrix = Xmatrix(:,1:F);

% PCA reference feature space.
[U, D, V] = svd(Xmatrix);
Zmatrix = Xmatrix*V;
Zmin = min(Zmatrix);
Zmax = max(Zmatrix);

% Within dispersion measures at the reference feature space.
Wstar = zeros(K, B);
for b = 1:B
    for f = 1:F
        Zmatrix(:,f) = unifrnd(Zmin(f), Zmax(f), N, 1);
    end
    Zmatrix = Zmatrix*V';
    ZDistanceVector = pdist(Zmatrix);
    L = linkage(ZDistanceVector, 'single');
    ZClusters = cluster(L, 'maxclust', 1:K);
    Wstar(:,b) = WithinDispersion(ZDistanceVector, ZClusters, K);
end

logWmean = mean(log(Wstar), 2);
logWstd = std(log(Wstar), 1, 2)*sqrt(1 + 1/B);
GAPstat = logWmean - log(W);

WhoseK = GAPstat(1:K-1) - GAPstat(2:K) + logWstd(2:K);

R = find(WhoseK >= 0, 1, 'first');

% Within dispersion measures. Expression (2) at Tibshirani et al (2001).
function RW = WithinDispersion(DistanceVector, Clusters, K)

DistanceMatrix = squareform(DistanceVector);

RW = zeros(K,1);
for k = 1:K
    D = zeros(k,1);
    n = zeros(k,1);
    for r = 1:k
        Indexes = find(Clusters(:,k) == r);
        D(r) = sum(sum(DistanceMatrix(Indexes,Indexes)));
        n(r) = 2*sum(length(Indexes));
    end
    RW(k) = sum(D./n);
end





