
function RW = WithinDispersion2(DistanceVector, Clusters, K)

DistanceMatrix = squareform(DistanceVector);

RW = zeros(K,1);
for k = 1:K
    D = zeros(k,1);
    n = zeros(k,1);
    for r = 1:k
        Indexes = find(Clusters(:,k) == r);
        D(r) = sum(sum(DistanceMatrix(Indexes,Indexes)));
        n(r) = 2*sum(length(Indexes));
    end
    RW(k) = sum(D./n);
end