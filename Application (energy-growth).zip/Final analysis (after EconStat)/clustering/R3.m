
function [R3_EPCC,R3_GDPC,R3_GCF]=R3;
%% Import the data
[~, ~, raw] = xlsread('baseregiones.xlsx','R3','B2:BL45');
raw(cellfun(@(x) ~isempty(x) && isnumeric(x) && isnan(x),raw)) = {''};
raw = raw(:,[1:63]);
%% Create output variable
data = reshape([raw{:}],size(raw));

%% Allocate imported array to column variable names
ALB_EPCC=data(:,1);
ALB_GDPC=data(:,2);
ALB_GCF=data(:,3);
AUT_EPCC=data(:,4);
AUT_GDPC=data(:,5);
AUT_GCF=data(:,6);
BEL_EPCC=data(:,7);
BEL_GDPC=data(:,8);
BEL_GCF=data(:,9);
BGR_EPCC=data(:,10);
BGR_GDPC=data(:,11);
BGR_GCF=data(:,12);
CYP_EPCC=data(:,13);
CYP_GDPC=data(:,14);
CYP_GCF=data(:,15);
DNK_EPCC=data(:,16);
DNK_GDPC=data(:,17);
DNK_GCF=data(:,18);
FIN_EPCC=data(:,19);
FIN_GDPC=data(:,20);
FIN_GCF=data(:,21);
FRA_EPCC=data(:,22);
FRA_GDPC=data(:,23);
FRA_GCF=data(:,24);
DEU_EPCC=data(:,25);
DEU_GDPC=data(:,26);
DEU_GCF=data(:,27);
GRC_EPCC=data(:,28);
GRC_GDPC=data(:,29);
GRC_GCF=data(:,30);
ISL_EPCC=data(:,31);
ISL_GDPC=data(:,32);
ISL_GCF=data(:,33);
IRL_EPCC=data(:,34);
IRL_GDPC=data(:,35);
IRL_GCF=data(:,36);
ITA_EPCC=data(:,37);
ITA_GDPC=data(:,38);
ITA_GCF=data(:,39);
LUX_EPCC=data(:,40);
LUX_GDPC=data(:,41);
LUX_GCF=data(:,42);
NLD_EPCC=data(:,43);
NLD_GDPC=data(:,44);
NLD_GCF=data(:,45);
NOR_EPCC=data(:,46);
NOR_GDPC=data(:,47);
NOR_GCF=data(:,48);
PRT_EPCC=data(:,49);
PRT_GDPC=data(:,50);
PRT_GCF=data(:,51);
ESP_EPCC=data(:,52);
ESP_GDPC=data(:,53);
ESP_GCF=data(:,54);
SWE_EPCC=data(:,55);
SWE_GDPC=data(:,56);
SWE_GCF=data(:,57);
SWI_EPCC=data(:,58);
SWI_GDPC=data(:,59);
SWI_GCF=data(:,60);
SWI2_EPCC=data(:,61);
SWI2_GDPC=data(:,62);
SWI2_GCF=data(:,63);

R3_EPCC=[ALB_EPCC	AUT_EPCC	BEL_EPCC	BGR_EPCC	CYP_EPCC	DNK_EPCC	FIN_EPCC	FRA_EPCC	DEU_EPCC	GRC_EPCC	ISL_EPCC	IRL_EPCC	ITA_EPCC	LUX_EPCC	NLD_EPCC	NOR_EPCC	PRT_EPCC	ESP_EPCC	SWE_EPCC	SWI_EPCC SWI2_EPCC];
R3_GDPC=[ALB_GDPC	AUT_GDPC	BEL_GDPC	BGR_GDPC	CYP_GDPC	DNK_GDPC	FIN_GDPC	FRA_GDPC	DEU_GDPC	GRC_GDPC	ISL_GDPC	IRL_GDPC	ITA_GDPC	LUX_GDPC	NLD_GDPC	NOR_GDPC	PRT_GDPC	ESP_GDPC	SWE_GDPC	SWI_GDPC SWI2_GDPC];
R3_GCF=[ALB_GCF	AUT_GCF	BEL_GCF	BGR_GCF	CYP_GCF	DNK_GCF	FIN_GCF	FRA_GCF	DEU_GCF	GRC_GCF	ISL_GCF	IRL_GCF	ITA_GCF	LUX_GCF	NLD_GCF	NOR_GCF	PRT_GCF	ESP_GCF	SWE_GCF	SWI_GCF SWI2_GCF];
%% Clear temporary variables
%clearvars data raw cellVectors;