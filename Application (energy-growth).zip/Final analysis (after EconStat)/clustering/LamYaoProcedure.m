% Implements the Lam and Yao procedure to find the numbers of factors.

function [R1, R2, R3] = LamYaoProcedure(Xseries, k0, kmax, toplot, twostep)

[T m] = size(Xseries);

for i = 1:m
    Xseries(:,i) = Xseries(:,i) - mean(Xseries(:,i));
end

Gamma = zeros(m,m,k0);
Mk0 = zeros(m,m);

for k = 1:k0
    G = cov([Xseries(1:T-k,:) Xseries(k+1:T,:)]);
    G = G(m+1:2*m, m+1:2*m);
    Gamma(:,:,k) = G;
    Mk0 = Mk0 + G*G';
end

[P1, lambda1] = eig(Mk0);
lambda1 = diag(lambda1);
lambda1 = lambda1(end:-1:end-kmax+1);

r1 = find(lambda1(2:kmax)./lambda1(1:kmax-1) == min(lambda1(2:kmax)./lambda1(1:kmax-1)));

if twostep == 1
    % We look for "weak" factors.
    P1 = P1(:,end:-1:end-r1+1);
    Yseries = ((eye(m) - P1*P1')*Xseries')';
    
    Gamma = zeros(m,m,k0);
    Mk0 = zeros(m,m);
    
    for k = 1:k0
        G = cov([Yseries(1:T-k,:) Yseries(k+1:T,:)]);
        G = G(m+1:2*m, m+1:2*m);
        Gamma(:,:,k) = G;
        Mk0 = Mk0 + G*G';
    end
    
    [P2, lambda2] = eig(Mk0);
    lambda2 = diag(lambda2);
    lambda2 = lambda2(end:-1:end-kmax+1);
    
    r2 = find(lambda2(2:kmax)./lambda2(1:kmax-1) == min(lambda2(2:kmax)./lambda2(1:kmax-1)));
    
    R1 = r1 + r2; % Number of common factors.
    
    R2 = [P1 P2(:,end:-1:end-r2+1)]; % Matrix loading estimation.
    
    R3 = Xseries*[P1 P2(:,end:-1:end-r2+1)]; % Factors estimation.
else
    R1 = r1; % Number of common factors.
    R2 = P1(:,end:-1:end-r1+1); % Matrix loading estimation.
    R3 = Xseries*R2; % Factors estimation.
end

if toplot == 1
    plot(lambda1(2:kmax)./lambda1(1:kmax-1), 'bo-')
    hold on
    plot(lambda2(2:kmax)./lambda2(1:kmax-1), 'r.-')
end

