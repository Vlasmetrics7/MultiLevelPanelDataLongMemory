function  x = filtro_hperiods(series, k, alpha, gamma)
[n] = size(series,1);
x = series;

    idxArray_left=bsxfun(@plus,(k+1:n)',-k:-1);
    idxArray_fill_left=bsxfun(@plus,(1:k)',1:k);
    matrix_left=[idxArray_fill_left; idxArray_left];
    clear idxArray_fill_left idxArray_left;
    idxArray_right=bsxfun(@plus,(1:n-k)',1:k);
    idxArray_fill_right=bsxfun(@plus,(n-k+1:n)',-k:-1);
    matrix_right=[idxArray_right; idxArray_fill_right];      
    clear idxArray_fill_right idxArray_right;
    idx_matrix=[matrix_left matrix_right];

    neigh_matrix=x(idx_matrix);
    clear idx_matrix;
    trimmed_mean=median(neigh_matrix,2);
    score=bsxfun(@minus,x,trimmed_mean);
    sd=std(neigh_matrix,0,2);
    clear neigh_matrix;

    temp = abs(score) > (alpha .* sd + gamma);
    outmat = temp*1;
    clear temp

outlier_num=find(outmat);
x(outlier_num)=trimmed_mean(outlier_num);
