% Univariate selection of K and K2 (not used in the paper).

function [R1, R2] = KUnivariateSelection(Zdata, Pmax, Criterio)

[T, ng] = size(Zdata);

Pselected = 0;
P2selected = 0;
for i = 1:ng
    [Psel, Resid] = ARselect(Zdata(:,i), Pmax, Criterio);
    Pselected = max(Pselected, Psel);
    Rdata = Resid.^2;
    Psel = ARselect(Rdata, Pmax, Criterio);
    P2selected = max(P2selected, Psel);
end

R1 = Pselected;
R2 = P2selected;

