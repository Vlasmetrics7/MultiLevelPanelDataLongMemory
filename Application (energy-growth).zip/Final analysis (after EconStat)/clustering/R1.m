function [R1_EPCC,R1_GDPC,R1_GCF]=R1;
%% Import the data
[~, ~, raw] = xlsread('baseregiones.xlsx','R1','B2:BX45');
raw(cellfun(@(x) ~isempty(x) && isnumeric(x) && isnan(x),raw)) = {''};
raw = raw(:,[1:75]);

%% Create output variable
data = reshape([raw{:}],size(raw));

%% Allocate imported array to column variable names
BGD_EPCC=data(:,1);
BGD_GDPC=data(:,2);
BGD_GCF=data(:,3);
IND_EPCC=data(:,4);
IND_GDPC=data(:,5);
IND_GCF=data(:,6);
NPL_EPCC=data(:,7);
NPL_GDPC=data(:,8);
NPL_GCF=data(:,9);
PAK_EPCC=data(:,10);
PAK_GDPC=data(:,11);
PAK_GCF=data(:,12);
LKA_EPCC=data(:,13);
LKA_GDPC=data(:,14);
LKA_GCF=data(:,15);
AUS_EPCC=data(:,16);
AUS_GDPC=data(:,17);
AUS_GCF=data(:,18);
BRN_EPCC=data(:,19);
BRN_GDPC=data(:,20);
BRN_GCF=data(:,21);
CHN_EPCC=data(:,22);
CHN_GDPC=data(:,23);
CHN_GCF=data(:,24);
HKG_EPCC=data(:,25);
HKG_GDPC=data(:,26);
HKG_GCF=data(:,27);
IDN_EPCC=data(:,28);
IDN_GDPC=data(:,29);
IDN_GCF=data(:,30);
JPN_EPCC=data(:,31);
JPN_GDPC=data(:,32);
JPN_GCF=data(:,33);
KOR_EPCC=data(:,34);
KOR_GDPC=data(:,35);
KOR_GCF=data(:,36);
MYS_EPCC=data(:,37);
MYS_GDPC=data(:,38);
MYS_GCF=data(:,39);
MMR_EPCC=data(:,40);
MMR_GDPC=data(:,41);
MMR_GCF=data(:,42);
NZL_EPCC=data(:,43);
NZL_GDPC=data(:,44);
NZL_GCF=data(:,45);
PHL_EPCC=data(:,46);
PHL_GDPC=data(:,47);
PHL_GCF=data(:,48);
SGP_EPCC=data(:,49);
SGP_GDPC=data(:,50);
SGP_GCF=data(:,51);
THA_EPCC=data(:,52);
THA_GDPC=data(:,53);
THA_GCF=data(:,54);
BHR_EPCC=data(:,55);
BHR_GDPC=data(:,56);
BHR_GCF=data(:,57);
IRN_EPCC=data(:,58);
IRN_GDPC=data(:,59);
IRN_GCF=data(:,60);
IRQ_EPCC=data(:,61);
IRQ_GDPC=data(:,62);
IRQ_GCF=data(:,63);
ISR_EPCC=data(:,64);
ISR_GDPC=data(:,65);
ISR_GCF=data(:,66);
JOR_EPCC=data(:,67);
JOR_GDPC=data(:,68);
JOR_GCF=data(:,69);
OMN_EPCC=data(:,70);
OMN_GDPC=data(:,71);
OMN_GCF=data(:,72);
SAU_EPCC=data(:,73);
SAU_GDPC=data(:,74);
SAU_GCF=data(:,75);



R1_EPCC=[BGD_EPCC	IND_EPCC	NPL_EPCC	PAK_EPCC	LKA_EPCC	AUS_EPCC	BRN_EPCC	CHN_EPCC	HKG_EPCC	IDN_EPCC	JPN_EPCC	KOR_EPCC	MYS_EPCC	MMR_EPCC	NZL_EPCC	PHL_EPCC	SGP_EPCC	THA_EPCC	BHR_EPCC	IRN_EPCC	IRQ_EPCC	ISR_EPCC	JOR_EPCC	OMN_EPCC	SAU_EPCC];
R1_GDPC=[BGD_GDPC	IND_GDPC	NPL_GDPC	PAK_GDPC	LKA_GDPC	AUS_GDPC	BRN_GDPC	CHN_GDPC	HKG_GDPC	IDN_GDPC	JPN_GDPC	KOR_GDPC	MYS_GDPC	MMR_GDPC	NZL_GDPC	PHL_GDPC	SGP_GDPC	THA_GDPC	BHR_GDPC	IRN_GDPC	IRQ_GDPC	ISR_GDPC	JOR_GDPC	OMN_GDPC	SAU_GDPC];
R1_GCF=[BGD_GCF	IND_GCF	NPL_GCF	PAK_GCF	LKA_GCF	AUS_GCF	BRN_GCF	CHN_GCF	HKG_GCF	IDN_GCF	JPN_GCF	KOR_GCF	MYS_GCF	MMR_GCF	NZL_GCF	PHL_GCF	SGP_GCF	THA_GCF	BHR_GCF	IRN_GCF	IRQ_GCF	ISR_GCF	JOR_GCF	OMN_GCF	SAU_GCF];



%% Clear temporary variables
%clearvars data raw cellVectors;