%
% This function implements the selection of an AR model using the AIC or
% BIC criterion.
%
% Inputs:
% Xseries : Time series (N x 1).
% Pmax : Maximum considered order.
% Criterion : AIC or BIC.
%
% Outputs:
% R1 : Selected order.
% R2 : Estimated residuals.
% R3 : Estimated autoregressive parameters.
%

function [R1, R2, R3] = ARselect(Xdata, Pmax, Criterion)

Sigma2 = zeros(Pmax+1,1);
Factor = zeros(Pmax+1,1);
N = length(Xdata);

Wseries = Xdata - mean(Xdata);
Xseries = [];
Yseries = Wseries(Pmax+1:end,1);
for p = 1:Pmax
    Xseries = [Xseries Wseries(Pmax+1-p:end-p,1)];
end

for p = 0:Pmax
    if p > 0
        [b,bint,r] = regress(Yseries,Xseries(:,1:p));
        Sigma2(p+1,1) = var(r);
        Factor(p+1,1) = p+1;
    else
        Sigma2(1,1) = var(Yseries);
        Factor(1,1) = 1;
    end
end

switch upper(Criterion)
    case 'AIC'
        IC = N*log(Sigma2) + 2*Factor;
    case 'BIC'
        IC = N*log(Sigma2) + Factor * log(N);
    otherwise
        display('Non included criterion -> AIC will be used')
        IC = N*log(Sigma2) + 2*Factor;
end

[ps] = find(IC == min(min(IC)));

if ps>1
    b = regress(Yseries,Xseries(:,1:ps-1));
    r = filter([1; -b], 1, Wseries);
    R2 = r - mean(r);
    R3 = b;
else
    R2 = Xdata - mean(Xdata);
    R3 = [];
end

R1 = ps-1;
