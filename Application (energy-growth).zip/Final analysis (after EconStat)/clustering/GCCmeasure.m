%
% This function implements the generalized cross correlations estimation.
%
% Inputs:
% Xdata, Ydata: Two time series.
% Lag : Maximum lag for GCC estimation.
%
% Output:
% R : GCC estimate.
%
function R = GCCmeasure(Xdata, Ydata, XLag)

Xdata = Xdata(:);
Ydata = Ydata(:);

TX = length(Xdata);
TY = length(Ydata);
T = min(TX, TY);

if nargin < 3
    XLag = min(10, T/10);
end

% Calculating GCC statistics.
Zdata = zeros(T-XLag, 2*(XLag+1));
for i = 1:XLag+1
    Zdata(:,i) = Xdata(XLag+2-i:T-i+1);
    Zdata(:,i+XLag+1) = Ydata(XLag+2-i:T-i+1);
end

CM = corrcoef(Zdata);

R = (det(CM)/(det(CM(XLag+2:2*(XLag+1),XLag+2:2*(XLag+1)))*det(CM(1:XLag+1,1:XLag+1))))^(1/(XLag+1));

