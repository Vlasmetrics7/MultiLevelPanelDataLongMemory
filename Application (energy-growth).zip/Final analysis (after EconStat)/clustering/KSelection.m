% Selection of K on a given interval, [KL, KU].

function R1 = KSelection(Zdata, Pmax, Criterio, KL, KU)

[T, ng] = size(Zdata);

IC = zeros(KU,1);

Kselected = max(KL-1,0);
for i = 1:ng-1
    for j = i+1:ng
        Xdata = Zdata(:,i);
        Ydata = Zdata(:,j);
        
        % X versus Y
        Wdata = zeros(T-Pmax, 2*(Pmax+1));
        for l = 1:Pmax+1
            Wdata(:,l) = Xdata(Pmax+2-l:T-l+1);
            Wdata(:,l+Pmax+1) = Ydata(Pmax+2-l:T-l+1);
        end
        [b,bint,r] = regress(Wdata(:,1), [ones(T-Pmax,1) Wdata(:,Pmax+1+1)]);
        ICriterio = (T-Pmax)*log(var(r)) + log(T-Pmax)*2;
        Pselected = 0;
        
        kini = Kselected+1;
        for k = kini:KU
            [b,bint,r] = regress(Wdata(:,1), [ones(T-Pmax,1) Wdata(:,2:2+k-1) Wdata(:,Pmax+1+1:Pmax+1+k+1)]);
            IC(k) = (T-Pmax)*log(var(r)) + log(T-Pmax)*(2*(k+1));
        end
        IC(1:Kselected) = ICriterio+1;
        [IC1, PIC] = min(IC);
        if IC1 < ICriterio
            ICriterio = IC1;
            Pselected = PIC;
            if Pselected > Kselected
                Kselected = Pselected;
            end
        end
        
        % Y versus X
        Wdata = zeros(T-Pmax, 2*(Pmax+1));
        for l = 1:Pmax+1
            Wdata(:,l+Pmax+1) = Xdata(Pmax+2-l:T-l+1);
            Wdata(:,l) = Ydata(Pmax+2-l:T-l+1);
        end
        [b,bint,r] = regress(Wdata(:,1), [ones(T-Pmax,1) Wdata(:,Pmax+1+1)]);
        ICriterio = (T-Pmax)*log(var(r)) + log(T-Pmax)*2;
        Pselected = 0;

        kini = Kselected+1;
        for k = kini:KU
            [b,bint,r] = regress(Wdata(:,1), [ones(T-Pmax,1) Wdata(:,2:2+k-1) Wdata(:,Pmax+1+1:Pmax+1+k+1)]);
            IC(k) = (T-Pmax)*log(var(r)) + log(T-Pmax)*(2*(k+1));
        end
        IC(1:Kselected) = ICriterio+1;
        [IC1, PIC] = min(IC);
        if IC1 < ICriterio
            ICriterio = IC1;
            Pselected = PIC;
        end
        Kselected = max(Kselected, Pselected);
    end
end

R1 = Kselected;

