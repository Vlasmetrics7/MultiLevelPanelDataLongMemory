function R=memory_app

[auxR1_EPCC,auxR1_GDPC,auxR1_GCF]=R1;%R1T_EPCC=R1_EPCC';R1T_GDPC=R1_GDPC';
[auxR2_EPCC,auxR2_GDPC,auxR2_GCF]=R2;%R2T_EPCC=R2_EPCC';R2T_GDPC=R2_GDPC';
[auxR3_EPCC,auxR3_GDPC,auxR3_GCF]=R3;%R3T_EPCC=R3_EPCC';R3T_GDPC=R3_GDPC';
[auxR4_EPCC,auxR4_GDPC,auxR4_GCF]=R4;%R4T_EPCC=R4_EPCC';R4T_GDPC=R4_GDPC';

R1_EPCC=log(auxR1_EPCC);R1_GDPC=log(auxR1_GDPC);R1_GCF=log(auxR1_GCF);
R2_EPCC=log(auxR2_EPCC);R2_GDPC=log(auxR2_GDPC);R2_GCF=log(auxR2_GCF);
R3_EPCC=log(auxR3_EPCC);R3_GDPC=log(auxR3_GDPC);R3_GCF=log(auxR3_GCF);
R4_EPCC=log(auxR4_EPCC);R4_GDPC=log(auxR4_GDPC);R4_GCF=log(auxR4_GCF);


[T2,NR1]=size(R1_EPCC);
[~,NR2]=size(R2_EPCC);
[~,NR3]=size(R3_EPCC);
[~,NR4]=size(R4_EPCC);
m2 = fix(T2^0.65);	

%%%%%  ESTIMACION DE MEMORIA *****
% REGION 1
for i=1:NR1
R1h1EPCC(i) = adftest(R1_EPCC(:,i),'model','AR');
R1h2EPCC(i) = adftest(R1_EPCC(:,i),'model','ARD');
R1h3EPCC(i) = adftest(R1_EPCC(:,i),'model','TS');
R1h4EPCC(i) = pptest(R1_EPCC(:,i),'model','AR');
R1h5EPCC(i) = pptest(R1_EPCC(:,i),'model','ARD');
R1h6EPCC(i) = pptest(R1_EPCC(:,i),'model','TS');
KPSS1=Kapetanios_test(R1_EPCC(:,i),3,3,1,1,2);R1h7EPCC(i)=KPSS1.Des;
KPSS2=Kapetanios_test(R1_EPCC(:,i),3,3,1,2,2);R1h8EPCC(i)=KPSS2.Des;
KPSS3=Kapetanios_test(R1_EPCC(:,i),3,3,1,3,2);R1h9EPCC(i)=KPSS3.Des;
P971=P97_test(R1_EPCC(:,i),1,3,3,1);R1h10EPCC(i)=P971.Outcome;
P972=P97_test(R1_EPCC(:,i),1,3,3,2);R1h11EPCC(i)=P972.Outcome; 
P973=P97_test(R1_EPCC(:,i),1,3,3,3);R1h12EPCC(i)=P973.Outcome; 
ZA1=ZA_test(R1_EPCC(:,i),1,3,3,1);R1h13EPCC(i)=ZA1.Outcome;
ZA2=ZA_test(R1_EPCC(:,i),1,3,3,2);R1h13EPCC(i)=ZA2.Outcome;
ZA3=ZA_test(R1_EPCC(:,i),1,3,3,3);R1h13EPCC(i)=ZA3.Outcome;
dR1EPCC(i) = felw(R1_EPCC(:,i),0,m2);

R1h1GDPC(i) = adftest(R1_GDPC(:,i),'model','AR');
R1h2GDPC(i) = adftest(R1_GDPC(:,i),'model','ARD');
R1h3GDPC(i) = adftest(R1_GDPC(:,i),'model','TS');
R1h4GDPC(i) = pptest(R1_GDPC(:,i),'model','AR');
R1h5GDPC(i) = pptest(R1_GDPC(:,i),'model','ARD');
R1h6GDPC(i) = pptest(R1_GDPC(:,i),'model','TS');
KPSS1=Kapetanios_test(R1_GDPC(:,i),3,3,1,1,2);R1h7GDPC(i)=KPSS1.Des;
KPSS2=Kapetanios_test(R1_GDPC(:,i),3,3,1,2,2);R1h8GDPC(i)=KPSS2.Des;
KPSS3=Kapetanios_test(R1_GDPC(:,i),3,3,1,3,2);R1h9GDPC(i)=KPSS3.Des;
P971=P97_test(R1_GDPC(:,i),1,3,3,1);R1h10GDPC(i)=P971.Outcome;
P972=P97_test(R1_GDPC(:,i),1,3,3,2);R1h11GDPC(i)=P972.Outcome; 
P973=P97_test(R1_GDPC(:,i),1,3,3,3);R1h12GDPC(i)=P973.Outcome; 
ZA1=ZA_test(R1_GDPC(:,i),1,3,3,1);R1h13GDPC(i)=ZA1.Outcome;
ZA2=ZA_test(R1_GDPC(:,i),1,3,3,2);R1h13GDPC(i)=ZA2.Outcome;
ZA3=ZA_test(R1_GDPC(:,i),1,3,3,3);R1h13GDPC(i)=ZA3.Outcome;
dR1GDPC(i) = felw(R1_GDPC(:,i),0,m2);

R1h1GCF(i) = adftest(R1_GCF(:,i),'model','AR');
R1h2GCF(i) = adftest(R1_GCF(:,i),'model','ARD');
R1h3GCF(i) = adftest(R1_GCF(:,i),'model','TS');
R1h4GCF(i) = pptest(R1_GCF(:,i),'model','AR');
R1h5GCF(i) = pptest(R1_GCF(:,i),'model','ARD');
R1h6GCF(i) = pptest(R1_GCF(:,i),'model','TS');
KPSS1=Kapetanios_test(R1_GCF(:,i),3,3,1,1,2);R1h7GCF(i)=KPSS1.Des;
KPSS2=Kapetanios_test(R1_GCF(:,i),3,3,1,2,2);R1h8GCF(i)=KPSS2.Des;
KPSS3=Kapetanios_test(R1_GCF(:,i),3,3,1,3,2);R1h9GCF(i)=KPSS3.Des;
P971=P97_test(R1_GCF(:,i),1,3,3,1);R1h10GCF(i)=P971.Outcome;
P972=P97_test(R1_GCF(:,i),1,3,3,2);R1h11GCF(i)=P972.Outcome; 
P973=P97_test(R1_GCF(:,i),1,3,3,3);R1h12GCF(i)=P973.Outcome; 
ZA1=ZA_test(R1_GCF(:,i),1,3,3,1);R1h13GCF(i)=ZA1.Outcome;
ZA2=ZA_test(R1_GCF(:,i),1,3,3,2);R1h13GCF(i)=ZA2.Outcome;
ZA3=ZA_test(R1_GCF(:,i),1,3,3,3);R1h13GCF(i)=ZA3.Outcome;
dR1GCF(i) = felw(R1_GCF(:,i),0,m2);
end

% REGION 2
for i=1:NR2
R2h1EPCC(i) = adftest(R2_EPCC(:,i),'model','AR');
R2h2EPCC(i) = adftest(R2_EPCC(:,i),'model','ARD');
R2h3EPCC(i) = adftest(R2_EPCC(:,i),'model','TS');
R2h4EPCC(i) = pptest(R2_EPCC(:,i),'model','AR');
R2h5EPCC(i) = pptest(R2_EPCC(:,i),'model','ARD');
R2h6EPCC(i) = pptest(R2_EPCC(:,i),'model','TS');
KPSS1=Kapetanios_test(R2_EPCC(:,i),3,3,1,1,2);R2h7EPCC(i)=KPSS1.Des;
KPSS2=Kapetanios_test(R2_EPCC(:,i),3,3,1,2,2);R2h8EPCC(i)=KPSS2.Des;
KPSS3=Kapetanios_test(R2_EPCC(:,i),3,3,1,3,2);R2h9EPCC(i)=KPSS3.Des;
P971=P97_test(R2_EPCC(:,i),1,3,3,1);R2h10EPCC(i)=P971.Outcome;
P972=P97_test(R2_EPCC(:,i),1,3,3,2);R2h11EPCC(i)=P972.Outcome; 
P973=P97_test(R2_EPCC(:,i),1,3,3,3);R2h12EPCC(i)=P973.Outcome; 
ZA1=ZA_test(R2_EPCC(:,i),1,3,3,1);R2h13EPCC(i)=ZA1.Outcome;
ZA2=ZA_test(R2_EPCC(:,i),1,3,3,2);R2h13EPCC(i)=ZA2.Outcome;
ZA3=ZA_test(R2_EPCC(:,i),1,3,3,3);R2h13EPCC(i)=ZA3.Outcome;
dR2EPCC(i) = felw(R2_EPCC(:,i),0,m2);
 
R2h1GDPC(i) = adftest(R2_GDPC(:,i),'model','AR');
R2h2GDPC(i) = adftest(R2_GDPC(:,i),'model','ARD');
R2h3GDPC(i) = adftest(R2_GDPC(:,i),'model','TS');
R2h4GDPC(i) = pptest(R2_GDPC(:,i),'model','AR');
R2h5GDPC(i) = pptest(R2_GDPC(:,i),'model','ARD');
R2h6GDPC(i) = pptest(R2_GDPC(:,i),'model','TS');
KPSS1=Kapetanios_test(R2_GDPC(:,i),3,3,1,1,2);R2h7GDPC(i)=KPSS1.Des;
KPSS2=Kapetanios_test(R2_GDPC(:,i),3,3,1,2,2);R2h8GDPC(i)=KPSS2.Des;
KPSS3=Kapetanios_test(R2_GDPC(:,i),3,3,1,3,2);R2h9GDPC(i)=KPSS3.Des;
P971=P97_test(R2_GDPC(:,i),1,3,3,1);R2h10GDPC(i)=P971.Outcome;
P972=P97_test(R2_GDPC(:,i),1,3,3,2);R2h11GDPC(i)=P972.Outcome; 
P973=P97_test(R2_GDPC(:,i),1,3,3,3);R2h12GDPC(i)=P973.Outcome; 
ZA1=ZA_test(R2_GDPC(:,i),1,3,3,1);R2h13GDPC(i)=ZA1.Outcome;
ZA2=ZA_test(R2_GDPC(:,i),1,3,3,2);R2h13GDPC(i)=ZA2.Outcome;
ZA3=ZA_test(R2_GDPC(:,i),1,3,3,3);R2h13GDPC(i)=ZA3.Outcome;
dR2GDPC(i) = felw(R2_GDPC(:,i),0,m2);
 
R2h1GCF(i) = adftest(R2_GCF(:,i),'model','AR');
R2h2GCF(i) = adftest(R2_GCF(:,i),'model','ARD');
R2h3GCF(i) = adftest(R2_GCF(:,i),'model','TS');
R2h4GCF(i) = pptest(R2_GCF(:,i),'model','AR');
R2h5GCF(i) = pptest(R2_GCF(:,i),'model','ARD');
R2h6GCF(i) = pptest(R2_GCF(:,i),'model','TS');
KPSS1=Kapetanios_test(R2_GCF(:,i),3,3,1,1,2);R2h7GCF(i)=KPSS1.Des;
KPSS2=Kapetanios_test(R2_GCF(:,i),3,3,1,2,2);R2h8GCF(i)=KPSS2.Des;
KPSS3=Kapetanios_test(R2_GCF(:,i),3,3,1,3,2);R2h9GCF(i)=KPSS3.Des;
P971=P97_test(R2_GCF(:,i),1,3,3,1);R2h10GCF(i)=P971.Outcome;
P972=P97_test(R2_GCF(:,i),1,3,3,2);R2h11GCF(i)=P972.Outcome; 
P973=P97_test(R2_GCF(:,i),1,3,3,3);R2h12GCF(i)=P973.Outcome; 
ZA1=ZA_test(R2_GCF(:,i),1,3,3,1);R2h13GCF(i)=ZA1.Outcome;
ZA2=ZA_test(R2_GCF(:,i),1,3,3,2);R2h13GCF(i)=ZA2.Outcome;
ZA3=ZA_test(R2_GCF(:,i),1,3,3,3);R2h13GCF(i)=ZA3.Outcome;
dR2GCF(i) = felw(R2_GCF(:,i),0,m2);   
end

% REGION 3
for i=1:NR3
R3h1EPCC(i) = adftest(R3_EPCC(:,i),'model','AR');
R3h2EPCC(i) = adftest(R3_EPCC(:,i),'model','ARD');
R3h3EPCC(i) = adftest(R3_EPCC(:,i),'model','TS');
R3h4EPCC(i) = pptest(R3_EPCC(:,i),'model','AR');
R3h5EPCC(i) = pptest(R3_EPCC(:,i),'model','ARD');
R3h6EPCC(i) = pptest(R3_EPCC(:,i),'model','TS');
KPSS1=Kapetanios_test(R3_EPCC(:,i),3,3,1,1,2);R3h7EPCC(i)=KPSS1.Des;
KPSS2=Kapetanios_test(R3_EPCC(:,i),3,3,1,2,2);R3h8EPCC(i)=KPSS2.Des;
KPSS3=Kapetanios_test(R3_EPCC(:,i),3,3,1,3,2);R3h9EPCC(i)=KPSS3.Des;
P971=P97_test(R3_EPCC(:,i),1,3,3,1);R3h10EPCC(i)=P971.Outcome;
P972=P97_test(R3_EPCC(:,i),1,3,3,2);R3h11EPCC(i)=P972.Outcome; 
P973=P97_test(R3_EPCC(:,i),1,3,3,3);R3h12EPCC(i)=P973.Outcome; 
ZA1=ZA_test(R3_EPCC(:,i),1,3,3,1);R3h13EPCC(i)=ZA1.Outcome;
ZA2=ZA_test(R3_EPCC(:,i),1,3,3,2);R3h13EPCC(i)=ZA2.Outcome;
ZA3=ZA_test(R3_EPCC(:,i),1,3,3,3);R3h13EPCC(i)=ZA3.Outcome;
dR3EPCC(i) = felw(R3_EPCC(:,i),0,m2);
 
R3h1GDPC(i) = adftest(R3_GDPC(:,i),'model','AR');
R3h2GDPC(i) = adftest(R3_GDPC(:,i),'model','ARD');
R3h3GDPC(i) = adftest(R3_GDPC(:,i),'model','TS');
R3h4GDPC(i) = pptest(R3_GDPC(:,i),'model','AR');
R3h5GDPC(i) = pptest(R3_GDPC(:,i),'model','ARD');
R3h6GDPC(i) = pptest(R3_GDPC(:,i),'model','TS');
KPSS1=Kapetanios_test(R3_GDPC(:,i),3,3,1,1,2);R3h7GDPC(i)=KPSS1.Des;
KPSS2=Kapetanios_test(R3_GDPC(:,i),3,3,1,2,2);R3h8GDPC(i)=KPSS2.Des;
KPSS3=Kapetanios_test(R3_GDPC(:,i),3,3,1,3,2);R3h9GDPC(i)=KPSS3.Des;
P971=P97_test(R3_GDPC(:,i),1,3,3,1);R3h10GDPC(i)=P971.Outcome;
P972=P97_test(R3_GDPC(:,i),1,3,3,2);R3h11GDPC(i)=P972.Outcome; 
P973=P97_test(R3_GDPC(:,i),1,3,3,3);R3h12GDPC(i)=P973.Outcome; 
ZA1=ZA_test(R3_GDPC(:,i),1,3,3,1);R3h13GDPC(i)=ZA1.Outcome;
ZA2=ZA_test(R3_GDPC(:,i),1,3,3,2);R3h13GDPC(i)=ZA2.Outcome;
ZA3=ZA_test(R3_GDPC(:,i),1,3,3,3);R3h13GDPC(i)=ZA3.Outcome;
dR3GDPC(i) = felw(R3_GDPC(:,i),0,m2);
 
R3h1GCF(i) = adftest(R3_GCF(:,i),'model','AR');
R3h2GCF(i) = adftest(R3_GCF(:,i),'model','ARD');
R3h3GCF(i) = adftest(R3_GCF(:,i),'model','TS');
R3h4GCF(i) = pptest(R3_GCF(:,i),'model','AR');
R3h5GCF(i) = pptest(R3_GCF(:,i),'model','ARD');
R3h6GCF(i) = pptest(R3_GCF(:,i),'model','TS');
KPSS1=Kapetanios_test(R3_GCF(:,i),3,3,1,1,2);R3h7GCF(i)=KPSS1.Des;
KPSS2=Kapetanios_test(R3_GCF(:,i),3,3,1,2,2);R3h8GCF(i)=KPSS2.Des;
KPSS3=Kapetanios_test(R3_GCF(:,i),3,3,1,3,2);R3h9GCF(i)=KPSS3.Des;
P971=P97_test(R3_GCF(:,i),1,3,3,1);R3h10GCF(i)=P971.Outcome;
P972=P97_test(R3_GCF(:,i),1,3,3,2);R3h11GCF(i)=P972.Outcome; 
P973=P97_test(R3_GCF(:,i),1,3,3,3);R3h12GCF(i)=P973.Outcome; 
ZA1=ZA_test(R3_GCF(:,i),1,3,3,1);R3h13GCF(i)=ZA1.Outcome;
ZA2=ZA_test(R3_GCF(:,i),1,3,3,2);R3h13GCF(i)=ZA2.Outcome;
ZA3=ZA_test(R3_GCF(:,i),1,3,3,3);R3h13GCF(i)=ZA3.Outcome;
dR3GCF(i) = felw(R3_GCF(:,i),0,m2);    
end

% REGION 4
for i=1:NR4
R4h1EPCC(i) = adftest(R4_EPCC(:,i),'model','AR');
R4h2EPCC(i) = adftest(R4_EPCC(:,i),'model','ARD');
R4h3EPCC(i) = adftest(R4_EPCC(:,i),'model','TS');
R4h4EPCC(i) = pptest(R4_EPCC(:,i),'model','AR');
R4h5EPCC(i) = pptest(R4_EPCC(:,i),'model','ARD');
R4h6EPCC(i) = pptest(R4_EPCC(:,i),'model','TS');
KPSS1=Kapetanios_test(R4_EPCC(:,i),3,3,1,1,2);R4h7EPCC(i)=KPSS1.Des;
KPSS2=Kapetanios_test(R4_EPCC(:,i),3,3,1,2,2);R4h8EPCC(i)=KPSS2.Des;
KPSS3=Kapetanios_test(R4_EPCC(:,i),3,3,1,3,2);R4h9EPCC(i)=KPSS3.Des;
P971=P97_test(R4_EPCC(:,i),1,3,3,1);R4h10EPCC(i)=P971.Outcome;
P972=P97_test(R4_EPCC(:,i),1,3,3,2);R4h11EPCC(i)=P972.Outcome; 
P973=P97_test(R4_EPCC(:,i),1,3,3,3);R4h12EPCC(i)=P973.Outcome; 
ZA1=ZA_test(R4_EPCC(:,i),1,3,3,1);R4h13EPCC(i)=ZA1.Outcome;
ZA2=ZA_test(R4_EPCC(:,i),1,3,3,2);R4h13EPCC(i)=ZA2.Outcome;
ZA3=ZA_test(R4_EPCC(:,i),1,3,3,3);R4h13EPCC(i)=ZA3.Outcome;
dR4EPCC(i) = felw(R4_EPCC(:,i),0,m2);
 
R4h1GDPC(i) = adftest(R4_GDPC(:,i),'model','AR');
R4h2GDPC(i) = adftest(R4_GDPC(:,i),'model','ARD');
R4h3GDPC(i) = adftest(R4_GDPC(:,i),'model','TS');
R4h4GDPC(i) = pptest(R4_GDPC(:,i),'model','AR');
R4h5GDPC(i) = pptest(R4_GDPC(:,i),'model','ARD');
R4h6GDPC(i) = pptest(R4_GDPC(:,i),'model','TS');
KPSS1=Kapetanios_test(R4_GDPC(:,i),3,3,1,1,2);R4h7GDPC(i)=KPSS1.Des;
KPSS2=Kapetanios_test(R4_GDPC(:,i),3,3,1,2,2);R4h8GDPC(i)=KPSS2.Des;
KPSS3=Kapetanios_test(R4_GDPC(:,i),3,3,1,3,2);R4h9GDPC(i)=KPSS3.Des;
P971=P97_test(R4_GDPC(:,i),1,3,3,1);R4h10GDPC(i)=P971.Outcome;
P972=P97_test(R4_GDPC(:,i),1,3,3,2);R4h11GDPC(i)=P972.Outcome; 
P973=P97_test(R4_GDPC(:,i),1,3,3,3);R4h12GDPC(i)=P973.Outcome; 
ZA1=ZA_test(R4_GDPC(:,i),1,3,3,1);R4h13GDPC(i)=ZA1.Outcome;
ZA2=ZA_test(R4_GDPC(:,i),1,3,3,2);R4h13GDPC(i)=ZA2.Outcome;
ZA3=ZA_test(R4_GDPC(:,i),1,3,3,3);R4h13GDPC(i)=ZA3.Outcome;
dR4GDPC(i) = felw(R4_GDPC(:,i),0,m2);
 
R4h1GCF(i) = adftest(R4_GCF(:,i),'model','AR');
R4h2GCF(i) = adftest(R4_GCF(:,i),'model','ARD');
R4h3GCF(i) = adftest(R4_GCF(:,i),'model','TS');
R4h4GCF(i) = pptest(R4_GCF(:,i),'model','AR');
R4h5GCF(i) = pptest(R4_GCF(:,i),'model','ARD');
R4h6GCF(i) = pptest(R4_GCF(:,i),'model','TS');
KPSS1=Kapetanios_test(R4_GCF(:,i),3,3,1,1,2);R4h7GCF(i)=KPSS1.Des;
KPSS2=Kapetanios_test(R4_GCF(:,i),3,3,1,2,2);R4h8GCF(i)=KPSS2.Des;
KPSS3=Kapetanios_test(R4_GCF(:,i),3,3,1,3,2);R4h9GCF(i)=KPSS3.Des;
P971=P97_test(R4_GCF(:,i),1,3,3,1);R4h10GCF(i)=P971.Outcome;
P972=P97_test(R4_GCF(:,i),1,3,3,2);R4h11GCF(i)=P972.Outcome; 
P973=P97_test(R4_GCF(:,i),1,3,3,3);R4h12GCF(i)=P973.Outcome; 
ZA1=ZA_test(R4_GCF(:,i),1,3,3,1);R4h13GCF(i)=ZA1.Outcome;
ZA2=ZA_test(R4_GCF(:,i),1,3,3,2);R4h13GCF(i)=ZA2.Outcome;
ZA3=ZA_test(R4_GCF(:,i),1,3,3,3);R4h13GCF(i)=ZA3.Outcome;
dR4GCF(i) = felw(R4_GCF(:,i),0,m2);
end

%RESULTS

%Region 1

R1EPCC=[R1h1EPCC,R1h2EPCC,R1h3EPCC,R1h4EPCC,R1h5EPCC,R1h6EPCC,R1h7EPCC,...
    R1h8EPCC,R1h9EPCC,R1h10EPCC,R1h11EPCC,R1h12EPCC,R1h13EPCC,R1dR1EPCC];

R1GDPC=[R1h1GDPC,R1h2GDPC,R1h3GDPC,R1h4GDPC,R1h5GDPC,R1h6GDPC,R1h7GDPC,...
    R1h8GDPC,R1h9GDPC,R1h10GDPC,R1h11GDPC,R1h12GDPC,R1h13GDPC,R1dR1GDPC];

R1GCF=[R1h1GCF,R1h2GCF,R1h3GCF,R1h4GCF,R1h5GCF,R1h6GCF,R1h7GCF,...
    R1h8GCF,R1h9GCF,R1h10GCF,R1h11GCF,R1h12GCF,R1h13GCF,R1dR1GCF];

%Region 2
 
R2EPCC=[R2h1EPCC,R2h2EPCC,R2h3EPCC,R2h4EPCC,R2h5EPCC,R2h6EPCC,R2h7EPCC,...
    R2h8EPCC,R2h9EPCC,R2h10EPCC,R2h11EPCC,R2h12EPCC,R2h13EPCC,R2dR2EPCC];
 
R2GDPC=[R2h1GDPC,R2h2GDPC,R2h3GDPC,R2h4GDPC,R2h5GDPC,R2h6GDPC,R2h7GDPC,...
    R2h8GDPC,R2h9GDPC,R2h10GDPC,R2h11GDPC,R2h12GDPC,R2h13GDPC,R2dR2GDPC];
 
R2GCF=[R2h1GCF,R2h2GCF,R2h3GCF,R2h4GCF,R2h5GCF,R2h6GCF,R2h7GCF,...
    R2h8GCF,R2h9GCF,R2h10GCF,R2h11GCF,R2h12GCF,R2h13GCF,R2dR2GCF];

%Region 3
 
R3EPCC=[R3h1EPCC,R3h2EPCC,R3h3EPCC,R3h4EPCC,R3h5EPCC,R3h6EPCC,R3h7EPCC,...
    R3h8EPCC,R3h9EPCC,R3h10EPCC,R3h11EPCC,R3h12EPCC,R3h13EPCC,R3dR3EPCC];
 
R3GDPC=[R3h1GDPC,R3h2GDPC,R3h3GDPC,R3h4GDPC,R3h5GDPC,R3h6GDPC,R3h7GDPC,...
    R3h8GDPC,R3h9GDPC,R3h10GDPC,R3h11GDPC,R3h12GDPC,R3h13GDPC,R3dR3GDPC];
 
R3GCF=[R3h1GCF,R3h2GCF,R3h3GCF,R3h4GCF,R3h5GCF,R3h6GCF,R3h7GCF,...
    R3h8GCF,R3h9GCF,R3h10GCF,R3h11GCF,R3h12GCF,R3h13GCF,R3dR3GCF];

%Region 4
 
R4EPCC=[R4h1EPCC,R4h2EPCC,R4h3EPCC,R4h4EPCC,R4h5EPCC,R4h6EPCC,R4h7EPCC,...
    R4h8EPCC,R4h9EPCC,R4h10EPCC,R4h11EPCC,R4h12EPCC,R4h13EPCC,R4dR4EPCC];
 
R4GDPC=[R4h1GDPC,R4h2GDPC,R4h3GDPC,R4h4GDPC,R4h5GDPC,R4h6GDPC,R4h7GDPC,...
    R4h8GDPC,R4h9GDPC,R4h10GDPC,R4h11GDPC,R4h12GDPC,R4h13GDPC,R4dR4GDPC];
 
R4GCF=[R4h1GCF,R4h2GCF,R4h3GCF,R4h4GCF,R4h5GCF,R4h6GCF,R4h7GCF,...
    R4h8GCF,R4h9GCF,R4h10GCF,R4h11GCF,R4h12GCF,R4h13GCF,R4dR4GCF];

R.R1EPCC=R1EPCC;
R.R2EPCC=R2EPCC;
R.R3EPCC=R3EPCC;
R.R4EPCC=R4EPCC;
R.R1GDPC=R1GDPC;
R.R2GDPC=R2GDPC;
R.R3GDPC=R3GDPC;
R.R4GDPC=R4GDPC;
R.R1GCF=R1GCF;
R.R2GCF=R2GCF;
R.R3GCF=R3GCF;
R.R4GCF=R4GCF;



% 
% for i=1:NR1
% dR1_EPCC(i) = felw(R1_EPCC(:,i),0,m2);
% dR1_EPCCt(i) = felw(R1_EPCC(:,i),1,m2);
% dR1_GDPC(i) = felw(R1_GDPC(:,i),0,m2);
% dR1_GDPCt(i) = felw(R1_GDPC(:,i),1,m2);
% end
% 
% for i=1:NR2
%     dR2_EPCC(i) = felw(R2_EPCC(:,i),0,m2);
%     dR2_EPCCt(i) = felw(R2_EPCC(:,i),1,m2);
%     dR2_GDPC(i) = felw(R2_GDPC(:,i),0,m2);
%     dR2_GDPCt(i) = felw(R2_GDPC(:,i),1,m2);
% end
%     
% for i=1:NR3
%     dR3_EPCC(i) = felw(R3_EPCC(:,i),0,m2);
%     dR3_EPCCt(i) = felw(R3_EPCC(:,i),1,m2);
%     dR3_GDPC(i) = felw(R3_GDPC(:,i),0,m2);
%     dR3_GDPCt(i) = felw(R3_GDPC(:,i),1,m2);
% end
%     
% for i=1:NR4
%     dR4_EPCC(i) = felw(R4_EPCC(:,i),0,m2);
%     dR4_EPCCt(i) = felw(R4_EPCC(:,i),1,m2);
%     dR4_GDPC(i) = felw(R4_GDPC(:,i),0,m2);
%     dR4_GDPCt(i) = felw(R4_GDPC(:,i),1,m2);
%    end
%     
% for i=1:NR5
%     dR5_EPCC(i) = felw(R5_EPCC(:,i),0,m2);
%     dR5_EPCCt(i) = felw(R5_EPCC(:,i),1,m2);
%     dR5_GDPC(i) = felw(R5_GDPC(:,i),0,m2);
%     dR5_GDPCt(i) = felw(R5_GDPC(:,i),1,m2);
% end
%     
% % for i=1:NR6
% %     dR6_EPCC(i) = felw(R6_EPCC(:,i),0,m2);
% %     dR6_EPCCt(i) = felw(R6_EPCC(:,i),1,m2);
% %     dR6_GDPC(i) = felw(R6_GDPC(:,i),0,m2);
% %     dR6_GDPCt(i) = felw(R6_GDPC(:,i),1,m2);
% % end
% 
% Results.d_R1=[dR1_EPCC' dR1_EPCCt' dR1_GDPC' dR1_GDPCt']; 
% Results.d_R2=[dR2_EPCC' dR2_EPCCt' dR2_GDPC' dR2_GDPCt']; 
% Results.d_R3=[dR3_EPCC' dR3_EPCCt' dR3_GDPC' dR3_GDPCt']; 
% Results.d_R4=[dR4_EPCC' dR4_EPCCt' dR4_GDPC' dR4_GDPCt']; 
% Results.d_R5=[dR5_EPCC' dR5_EPCCt' dR5_GDPC' dR5_GDPCt']; 
% %Results.d_R6=[dR6_EPCC' dR6_EPCCt' dR6_GDPC' dR6_GDPCt']; 
% 
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% EPCC=[R1_EPCC R2_EPCC R3_EPCC R4_EPCC R5_EPCC];EPCC=EPCC';
% GDPC=[R1_GDPC R2_GDPC R3_GDPC R4_GDPC R5_GDPC];GDPC=GDPC';
% 
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %%%%%%%%%%%% ESTIMATION %%%%%%%%%%%%%%
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %%%%%% ERGEMEN & VELASCO (2017) %%%%%%
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
% deltaxstar=fracdiff(EPCC',2)'; 
% deltaystar=fracdiff(GDPC',2)';
% 
% csavgxstar=mean(deltaxstar);
% csavgystar=mean(deltaystar);
% 
% H=[csavgystar' csavgxstar']';
% Hs=H'*pinv(H*H')*H;
% I=eye(size(Hs));
% W=I-Hs;
% 
% yproj=W*GDPC';
% xproj=W*EPCC';
% 
% phi1=zeros(200,1);
% likel=zeros(200,1);
% for d=0.01:0.01:2
%     ddy_prev=fracdiff(yproj,d);   
%     ddx_prev=fracdiff(xproj,d); 
%     
%     pool_ddy=ddy_prev'; pool_ddx=ddx_prev';
%     ddy=pool_ddy(:); ddx=pool_ddx(:);
%     
%     phi1(int32(d*100),1)=(ddx'*ddy)/(ddx'*ddx);
%             
%     likel(int32(d*100),1)=mean((ddy-ddx.*phi1(int32(d*100),1)).^2);
% end
%     
% [~,b]=min(likel);
% dest=b/100;
% 
% destdy=fracdiff(yproj,dest);
% destdx=fracdiff(xproj,dest);  
% 
% CCE=(diag(destdx'*destdx)).^(-1).*diag(destdx'*destdy);
% CCEMG= mean(CCE);
% Results.CCE=CCE;Results.CCEMG= CCEMG;
% 
% Sx=zeros(95,1);Sy=zeros(95,1);
% for i=1:95
% Sx(i)=destdx(:,i)'*destdx(:,i);
% Sy(i)=destdx(:,i)'*destdy(:,i);
% end
% 
% CCEP = sum(Sy)/sum(Sx);Results.CCEP=CCEP;
% 
% memest_ccemg=zeros(95,1);
% for i=1:95
% memest_ccemg(i)=fminbnd(@(d)(1/T2)*sum(fracdiff((yproj(:,i)-CCEMG*xproj(:,i)),d).^2), 0, 2);
% end
% 
% memest_ccep=zeros(95,1);
% for i=1:95
% memest_ccep(i)=fminbnd(@(d)(1/T2)*sum(fracdiff((yproj(:,i)-CCEP*xproj(:,i)),d).^2), 0, 2);
% end
% 
% Results.memest_ccemg=memest_ccemg;
% Results.memest_ccep=memest_ccep;
% 
% 
% 
% 
% 
% 
% 
%     
