function R=estim_velasco_M11 

[auxR1_EPCC,auxR1_GDPC,auxR1_GCF]=R1;
[auxR2_EPCC,auxR2_GDPC,auxR2_GCF]=R2;
[auxR3_EPCC,auxR3_GDPC,auxR3_GCF]=R3;
[auxR4_EPCC,auxR4_GDPC,auxR4_GCF]=R4;

R1_EPCC2=log(auxR1_EPCC);R1_GDPC2=log(auxR1_GDPC);R1_GCF2=log(auxR1_GCF);
R2_EPCC2=log(auxR2_EPCC);R2_GDPC2=log(auxR2_GDPC);R2_GCF2=log(auxR2_GCF);
R3_EPCC2=log(auxR3_EPCC);R3_GDPC2=log(auxR3_GDPC);R3_GCF2=log(auxR3_GCF);
R4_EPCC2=log(auxR4_EPCC);R4_GDPC2=log(auxR4_GDPC);R4_GCF2=log(auxR4_GCF);

%%%%%%%%%%% GCP EPCC GCF %%%%%%%%%%%%%%%%%%%%

R1_EPCC=R1_EPCC2(:,[1:2,5:8,10:14,17,19:20,22:24]);
R1_GDPC=R1_GDPC2(:,[1:2,5:8,10:14,17,19:20,22:24]);
R1_GCF=R1_GCF2(:,[1:2,5:8,10:14,17,19:20,22:24]);

R2_EPCC=R2_EPCC2(:,[1:12,14:19]);
R2_GDPC=R2_GDPC2(:,[1:12,14:19]);
R2_GCF=R2_GCF2(:,[1:12,14:19]);

R3_EPCC=R3_EPCC2(:,[1:3,5,7,9,11:13,15:19]);
R3_GDPC=R3_GDPC2(:,[1:3,5,7,9,11:13,15:19]);
R3_GCF=R3_GCF2(:,[1:3,5,7,9,11:13,15:19]);

R4_EPCC=R4_EPCC2(:,[1:6,8:13,15:17,19:23]);
R4_GDPC=R4_GDPC2(:,[1:6,8:13,15:17,19:23]);
R4_GCF=R4_GCF2(:,[1:6,8:13,15:17,19:23]);

auxEPCC=[R1_EPCC,R2_EPCC,R3_EPCC,R4_EPCC]; 
auxGDPC=[R1_GDPC,R2_GDPC,R3_GDPC,R4_GDPC]; 
auxGCF=[R1_GCF,R2_GCF,R3_GCF,R4_GCF]; 
EPCC2=auxEPCC;GDPC2=auxGDPC;GCF2=auxGCF;

%%%%%%%%%%% GCP EPCC %%%%%%%%%%%%%%%%%%%%

EPCCd=fracdiff(EPCC2,1);GDPCd=fracdiff(GDPC2,1);GCFd=fracdiff(GCF2,0.6);
EPCC=EPCCd(5:end,:)';GDPC=GDPCd(5:end,:)';GCF=GCFd(5:end,:)';
[NR,T]=size(EPCC);

csavgxstar=mean(EPCC);
csavgystar=mean(GDPC);
csavgzstar=mean(GCF);

H=[ones(size(csavgystar')) csavgystar' csavgxstar' csavgzstar']';
Hs=H'*pinv(H*H')*H;
I=eye(size(Hs));
W=I-Hs;

auxGDPCproj=W*GDPC'; %TXN
auxEPCCproj=W*EPCC'; 
auxGCFproj=W*GCF';


for i=1:NR
for d=0.001:0.001:1.5
    ddy_prev=fracdiff(auxGDPCproj(:,i),d);   
    ddx_prev=fracdiff(auxEPCCproj(:,i),d); 
    ddz_prev=fracdiff(auxGCFproj(:,i),d); 

    RES=ols(ddy_prev,[ddx_prev,ddz_prev]);
    phi1(int32(d*1000),1)=RES.beta(1);
    phi2(int32(d*1000),1)=RES.beta(2);
     
    likel(int32(d*1000),1)=mean((ddy_prev-ddx_prev.*phi1(int32(d*1000),1)-ddz_prev.*phi2(int32(d*1000),1)).^2);
end
  
[~,b]=min(likel);
dest=b/1000;

GDPCproj(:,i)=fracdiff(auxGDPCproj(:,i),dest+1);
EPCCproj(:,i)=fracdiff(auxEPCCproj(:,i),dest+1);  
GCFproj(:,i)=fracdiff(auxGCFproj(:,i),dest+1); 

     XM=[EPCCproj(:,i) GCFproj(:,i)];
     YM=[GDPCproj(:,i)];
     BETA=(XM'*XM)^(-1)*(XM'*YM);
     CCE_EPCC(i)=BETA(1); CCE_GCF(i)=BETA(2);
 end
 CCE_EPCC=CCE_EPCC';CCE_GCF=CCE_GCF';
R.CCE_EPCC=CCE_EPCC;R.CCE_GCF=CCE_GCF;
CCEMG_EPCC= mean(CCE_EPCC);CCEMG_GCF= mean(CCE_GCF);
R.CCEMG_EPCC=CCEMG_EPCC;R.CCEMG_GCF=CCEMG_GCF;

 %Standard deviation calculations
 for i=1:NR
     YM=[GDPCproj(:,i)];
     XM=[EPCCproj(:,i) GCFproj(:,i)];
 e = GDPCproj(:,i)-EPCCproj(:,i)*CCE_EPCC(i)-GCFproj(:,i)*CCE_GCF(i); %Estimated disturbances
 R.residuals(:,i)=e;
 se = NeweyWest(e,XM,0); R.se(i,:)=se';
 end

[Z1,~]=intercalar03(CCE_EPCC,R.se(:,1));
[Z2,~]=intercalar03(CCE_GCF,R.se(:,2));
ZRES=[Z1' Z2']; R.ZRES=ZRES;

 for i=1:NR
z1(i)=CCE_EPCC(i)/R.se(i,1);
z2(i)=CCE_GCF(i)/R.se(i,2);
pval1=2*(1-normcdf(abs(z1'),0,1));
PVAL1=pval1; R.PVAL1(i)=PVAL1(i);
pval2=2*(1-normcdf(abs(z2'),0,1));
PVAL2=pval2; R.PVAL2(i)=PVAL2(i);

 end
 sigma_CCEMG_EPCC= (1/NR)*(CCE_EPCC-CCEMG_EPCC)'*(CCE_EPCC-CCEMG_EPCC); 
 R.sigma_CCEMG_EPCC=sigma_CCEMG_EPCC;
 
 sigma_CCEMG_GCF= (1/NR)*(CCE_GCF-CCEMG_GCF)'*(CCE_GCF-CCEMG_GCF); 
 R.sigma_CCEMG_GCF=sigma_CCEMG_GCF;

 PVAL_CCEMG_EPCC=2*(1-normcdf(abs(CCEMG_EPCC/sigma_CCEMG_EPCC),0,1));
 R.PVAL_CCEMG_EPCC=PVAL_CCEMG_EPCC;
 
 PVAL_CCEMG_GCF=2*(1-normcdf(abs(CCEMG_GCF/sigma_CCEMG_GCF),0,1));
 R.PVAL_CCEMG_GCF=PVAL_CCEMG_GCF;
 
 %%%%%%%%%%% MEMORI %%%%%%%%%%%%%%%%%%%%

for i=1:NR
memest_cce(i)=fminbnd(@(df)(1/T)*sum(fracdiff(diff(auxGDPCproj(6:end,i)-CCE_EPCC(i)*auxEPCCproj(6:end,i)-CCE_GCF(i)*auxGCFproj(6:end,i)),df-1).^2), 0, 1.5);
end

R.memest=memest_cce;
 
 