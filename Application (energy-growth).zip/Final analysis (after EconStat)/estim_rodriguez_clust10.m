function R=estim_rodriguez_clust10

[auxR1_EPCC,auxR1_GDPC,auxR1_GCF]=R1;
[auxR2_EPCC,auxR2_GDPC,auxR2_GCF]=R2;
[auxR3_EPCC,auxR3_GDPC,auxR3_GCF]=R3;
[auxR4_EPCC,auxR4_GDPC,auxR4_GCF]=R4;

R1_EPCC2=log(auxR1_EPCC);R1_GDPC2=log(auxR1_GDPC);R1_GCF2=log(auxR1_GCF);
R2_EPCC2=log(auxR2_EPCC);R2_GDPC2=log(auxR2_GDPC);R2_GCF2=log(auxR2_GCF);
R3_EPCC2=log(auxR3_EPCC);R3_GDPC2=log(auxR3_GDPC);R3_GCF2=log(auxR3_GCF);
R4_EPCC2=log(auxR4_EPCC);R4_GDPC2=log(auxR4_GDPC);R4_GCF2=log(auxR4_GCF);

%%%%%%%%%%% GCP EPCC GCF %%%%%%%%%%%%%%%%%%%%

R1_EPCC=R1_EPCC2(:,[1:2,5:8,10:14,17,19:20,22:24]);
R1_GDPC=R1_GDPC2(:,[1:2,5:8,10:14,17,19:20,22:24]);
R1_GCF=R1_GCF2(:,[1:2,5:8,10:14,17,19:20,22:24]);

R2_EPCC=R2_EPCC2(:,[1:12,14:19]);
R2_GDPC=R2_GDPC2(:,[1:12,14:19]);
R2_GCF=R2_GCF2(:,[1:12,14:19]);

R3_EPCC=R3_EPCC2(:,[1:3,5,7,9,11:13,15:19]);
R3_GDPC=R3_GDPC2(:,[1:3,5,7,9,11:13,15:19]);
R3_GCF=R3_GCF2(:,[1:3,5,7,9,11:13,15:19]);

R4_EPCC=R4_EPCC2(:,[1:6,8:13,15:17,19:23]);
R4_GDPC=R4_GDPC2(:,[1:6,8:13,15:17,19:23]);
R4_GCF=R4_GCF2(:,[1:6,8:13,15:17,19:23]);

auxEPCC=[R1_EPCC,R2_EPCC,R3_EPCC,R4_EPCC]; 
auxGDPC=[R1_GDPC,R2_GDPC,R3_GDPC,R4_GDPC]; 
auxGCF=[R1_GCF,R2_GCF,R3_GCF,R4_GCF]; 
EPCC2=auxEPCC;GDPC2=auxGDPC;GCF2=auxGCF;

%%%%%%%%%%% GCP EPCC %%%%%%%%%%%%%%%%%%%%

C1_EPCC=EPCC2(:,[1	3	8	10	12	15	17	18	19	20	21	22	23	24	27	28	29	30	31	32	33	34	35	53	61	67]);
C1_GDPC=GDPC2(:,[1	3	8	10	12	15	17	18	19	20	21	22	23	24	27	28	29	30	31	32	33	34	35	53	61	67]);
C1_GCF=GCF2(:,[1	3	8	10	12	15	17	18	19	20	21	22	23	24	27	28	29	30	31	32	33	34	35	53	61	67]);

C2_EPCC=EPCC2(:,[2	4	5	6	7	9	14	25	37	40	41	43	48	49	50	54	55	56	59	63	64	66	69]);
C2_GDPC=GDPC2(:,[2	4	5	6	7	9	14	25	37	40	41	43	48	49	50	54	55	56	59	63	64	66	69]);
C2_GCF=GCF2(:,[2	4	5	6	7	9	14	25	37	40	41	43	48	49	50	54	55	56	59	63	64	66	69]);

C3_EPCC=EPCC2(:,[11	13	16	36	38	39	42	44	45	46	47	51	52	57	58	60	62	65	68	26]);
C3_GDPC=GDPC2(:,[11	13	16	36	38	39	42	44	45	46	47	51	52	57	58	60	62	65	68	26]);
C3_GCF=GCF2(:,[11	13	16	36	38	39	42	44	45	46	47	51	52	57	58	60	62	65	68	26]);

auxEPCC=[C1_EPCC,C2_EPCC,C3_EPCC]; 
auxGDPC=[C1_GDPC,C2_GDPC,C3_GDPC]; 
auxGCF=[C1_GCF,C2_GCF,C3_GCF]; 
EPCC2=auxEPCC;GDPC2=auxGDPC;GCF2=auxGCF;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5

EPCCd=fracdiff(EPCC2,1.5);GDPCd=fracdiff(GDPC2,1.5);GCFd=fracdiff(GCF2,1);
EPCC=EPCCd(5:end,:)';GDPC=GDPCd(5:end,:)';GCF=GCFd(5:end,:)';

[T,NR1]=size(R1_EPCC);
[~,NR2]=size(R2_EPCC);
[~,NR3]=size(R3_EPCC);

NR=NR1+NR2+NR3;

deltaxstar=EPCC;
deltaystar=GDPC;
deltazstar=GCF;

    y_R1=mean(deltaystar(1:NR1,:));  
    x_R1=mean(deltaxstar(1:NR1,:));  
    z_R1=mean(deltazstar(1:NR1,:));  
    H_R1=[y_R1' x_R1' z_R1']';
    Hs_R1=H_R1'*pinv(H_R1*H_R1')*H_R1;
    I_R1=eye(size(Hs_R1));
    W_R1=I_R1-Hs_R1;               
    xprojR1=W_R1*deltaxstar(1:NR1,:)';   
    yprojR1=W_R1*deltaystar(1:NR1,:)';   
    zprojR1=W_R1*deltazstar(1:NR1,:)';   
    
    y_R2=mean(deltaystar(NR1+1:NR1+NR2,:));  
    x_R2=mean(deltaxstar(NR1+1:NR1+NR2,:)); 
    z_R2=mean(deltazstar(NR1+1:NR1+NR2,:)); 
    H_R2=[y_R2' x_R2' z_R2']';
    Hs_R2=H_R2'*pinv(H_R2*H_R2')*H_R2;
    I_R2=eye(size(Hs_R2));
    W_R2=I_R2-Hs_R2;             
    xprojR2=W_R2*deltaxstar(NR1+1:NR1+NR2,:)';  
    yprojR2=W_R2*deltaystar(NR1+1:NR1+NR2,:)';
    zprojR2=W_R2*deltazstar(NR1+1:NR1+NR2,:)';

    y_R3=mean(deltaystar(NR1+NR2+1:NR1+NR2+NR3,:));  
    x_R3=mean(deltaxstar(NR1+NR2+1:NR1+NR2+NR3,:)); 
    z_R3=mean(deltazstar(NR1+NR2+1:NR1+NR2+NR3,:)); 
    H_R3=[y_R3' x_R3' z_R3']';
    Hs_R3=H_R3'*pinv(H_R3*H_R3')*H_R3;
    I_R3=eye(size(Hs_R3));
    W_R3=I_R3-Hs_R3;             
    xprojR3=W_R3*deltaxstar(NR1+NR2+1:NR1+NR2+NR3,:)';  
    yprojR3=W_R3*deltaystar(NR1+NR2+1:NR1+NR2+NR3,:)';
    zprojR3=W_R3*deltazstar(NR1+NR2+1:NR1+NR2+NR3,:)';

    auxEPCCproj=[xprojR1';xprojR2';xprojR3']';
    auxGDPCproj=[yprojR1';yprojR2';yprojR3']';
    auxGCFproj=[zprojR1';zprojR2';zprojR3']';
    
     
for i=1:NR
for d=0.001:0.001:1.5
    ddy_prev=fracdiff(auxGDPCproj(:,i),d);   
    ddx_prev=fracdiff(auxEPCCproj(:,i),d); 
    ddz_prev=fracdiff(auxGCFproj(:,i),d); 

    RES=ols(ddy_prev,[ddx_prev,ddz_prev]);
    phi1(int32(d*1000),1)=RES.beta(1);
    phi2(int32(d*1000),1)=RES.beta(2);
     
    likel(int32(d*1000),1)=mean((ddy_prev-ddx_prev.*phi1(int32(d*1000),1)-ddz_prev.*phi2(int32(d*1000),1)).^2);
end
  
[~,b]=min(likel);
dest=b/1000;

GDPCproj(:,i)=fracdiff(auxGDPCproj(:,i),dest+1);
EPCCproj(:,i)=fracdiff(auxEPCCproj(:,i),dest+1);  
GCFproj(:,i)=fracdiff(auxGCFproj(:,i),dest+1); 

     XM=[EPCCproj(:,i) GCFproj(:,i)];
     YM=[GDPCproj(:,i)];
     BETA=(XM'*XM)^(-1)*(XM'*YM);
     CCE_EPCC(i)=BETA(1); CCE_GCF(i)=BETA(2);
 end
 CCE_EPCC=CCE_EPCC';CCE_GCF=CCE_GCF';
R.CCE_EPCC=CCE_EPCC;R.CCE_GCF=CCE_GCF;
CCEMG_EPCC= mean(CCE_EPCC);CCEMG_GCF= mean(CCE_GCF);
R.CCEMG_EPCC=CCEMG_EPCC;R.CCEMG_GCF=CCEMG_GCF;

 %Standard deviation calculations
 for i=1:NR
     YM=[GDPCproj(:,i)];
     XM=[EPCCproj(:,i) GCFproj(:,i)];
 e = GDPCproj(:,i)-EPCCproj(:,i)*CCE_EPCC(i)-GCFproj(:,i)*CCE_GCF(i); %Estimated disturbances
 R.residuals(:,i)=e;
 se = NeweyWest(e,XM,0); R.se(i,:)=se';
 end

[Z1,~]=intercalar03(CCE_EPCC,R.se(:,1));
[Z2,~]=intercalar03(CCE_GCF,R.se(:,2));
ZRES=[Z1' Z2']; R.ZRES=ZRES;

 for i=1:NR
z1(i)=CCE_EPCC(i)/R.se(i,1);
z2(i)=CCE_GCF(i)/R.se(i,2);
pval1=2*(1-normcdf(abs(z1'),0,1));
PVAL1=pval1; R.PVAL1(i)=PVAL1(i);
pval2=2*(1-normcdf(abs(z2'),0,1));
PVAL2=pval2; R.PVAL2(i)=PVAL2(i);

 end
 sigma_CCEMG_EPCC= (1/NR)*(CCE_EPCC-CCEMG_EPCC)'*(CCE_EPCC-CCEMG_EPCC); 
 R.sigma_CCEMG_EPCC=sigma_CCEMG_EPCC;
 
 sigma_CCEMG_GCF= (1/NR)*(CCE_GCF-CCEMG_GCF)'*(CCE_GCF-CCEMG_GCF); 
 R.sigma_CCEMG_GCF=sigma_CCEMG_GCF;

 PVAL_CCEMG_EPCC=2*(1-normcdf(abs(CCEMG_EPCC/sigma_CCEMG_EPCC),0,1));
 R.PVAL_CCEMG_EPCC=PVAL_CCEMG_EPCC;
 
 PVAL_CCEMG_GCF=2*(1-normcdf(abs(CCEMG_GCF/sigma_CCEMG_GCF),0,1));
 R.PVAL_CCEMG_GCF=PVAL_CCEMG_GCF;
 
 %%%%%%%%%%% MEMORI %%%%%%%%%%%%%%%%%%%%

for i=1:NR
memest_cce(i)=fminbnd(@(df)(1/40)*sum(fracdiff(diff(auxGDPCproj(6:end,i)-CCE_EPCC(i)*auxEPCCproj(6:end,i)-CCE_GCF(i)*auxGCFproj(6:end,i)),df-1).^2), 0, 1.5);
end

R.memest=memest_cce;
 
