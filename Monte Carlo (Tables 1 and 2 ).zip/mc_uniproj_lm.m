
% UNI PROYECCION
%(N,T,dr,dg,vartheta,du,beta0,vlambda1,vlambda2,vgamma)

function [CCEMGBias,CCEMGRMSE,CCEPBias,CCEPRMSE,mem_ccemg,mem_ccep]=mc_uniproj_lm(Nr,T,beta0,stnr,stdreg,stdglob,dr,dg,dE,dU)

CCEMG_BIAS=zeros(500,1);CCEMG_RMSE=zeros(500,1);
CCEP_BIAS=zeros(500,1);CCEP_RMSE=zeros(500,1);
 parfor_progress(500);
parfor i=1:500
[CCEMG_BIAS(i),CCEMG_RMSE(i),CCEP_BIAS(i),CCEP_RMSE(i),mem_ccemg_bias(i),mem_ccep_bias(i)] = proyeccion(Nr,T,beta0,stnr,stdreg,stdglob,dr,dg,dE,dU);
parfor_progress;
end
parfor_progress(0);

CCEMGBias=mean(CCEMG_BIAS);
CCEMGRMSE=mean(CCEMG_RMSE);

CCEPBias=mean(CCEP_BIAS);
CCEPRMSE=mean(CCEP_RMSE);

mem_ccemg=mean(mem_ccemg_bias);
mem_ccep=mean(mem_ccep_bias);

function [CCEMG_BIAS,CCEMG_RMSE,CCEP_BIAS,CCEP_RMSE,mem_ccemg_bias,mem_ccep_bias] = proyeccion(Nr,T,beta0,stnr,stdreg,stdglob,dr,dg,dE,dU)


R1=dgp_arfima(0,0.5,[],T,stdreg,dr,0);
R2=dgp_arfima(0,0.5,[],T,stdreg,dr,0);
Rf=[R1,R2]';

Gl=dgp_arfima(0,0.5,[],T,stdglob,dg,0);
Gf=Gl';

u=fracdiff(normrnd(0,stnr,T,2*Nr),-dU);

E=fracdiff(normrnd(0,stnr,T,2*Nr),-dE);

lambda_r1=normrnd(1,1,Nr,1);
lambda_r2=normrnd(1,1,Nr,1);
gamma=normrnd(1,1,2*Nr,1);

lambda2_r1=normrnd(1,1,Nr,1);
lambda2_r2=normrnd(1,1,Nr,1);
gamma2=normrnd(1,1,2*Nr,1);
L_star = [gamma,[lambda_r1,zeros(Nr,1);zeros(Nr,1),lambda_r2]]; 
L_star2 = [gamma2,[lambda2_r1,zeros(Nr,1);zeros(Nr,1),lambda2_r2]]; 
F_star = [Gf;Rf];
U_star = u';
E_star = E';

x=L_star2*F_star+E_star;
                            R.x=x;
y=beta0*x+L_star * F_star+U_star;
                            R.y=y;

% FILTERING YUNUS
deltaxstar=fracdiff(x',1)'; 
deltaystar=fracdiff(y',1)';

csavgxstar=mean(deltaxstar);
csavgystar=mean(deltaystar);

H=[csavgystar' csavgxstar']';
Hs=H'*pinv(H*H')*H;
I=eye(size(Hs));
W=I-Hs;

yproj=W*y';
xproj=W*x';

R.yproj=yproj;R.xproj=xproj;

phi1=zeros(15,1);
likel=zeros(15,1);
for d=0.1:0.1:1.5
    ddy_prev=fracdiff(yproj,d);   
    ddx_prev=fracdiff(xproj,d); 
    
    pool_ddy=ddy_prev'; pool_ddx=ddx_prev';
    ddy=pool_ddy(:); ddx=pool_ddx(:);
    
    phi1(int32(d*10),1)=(ddx'*ddy)/(ddx'*ddx);
            
    likel(int32(d*10),1)=mean((ddy-ddx.*phi1(int32(d*10),1)).^2);
end
    
[~,b]=min(likel);
dest=b/10;

destdy=fracdiff(yproj,dest);
destdx=fracdiff(xproj,dest);  

CCE=(diag(destdx'*destdx)).^(-1).*diag(destdx'*destdy);
CCEMG= mean(CCE);

CCEMG_BIAS = CCEMG-beta0;
CCEMG_RMSE = sqrt(CCEMG_BIAS^2+var(CCEMG));

Sx=zeros(Nr*2,1);Sy=zeros(Nr*2,1);
for i=1:Nr*2
Sx(i)=destdx(:,i)'*destdx(:,i);
Sy(i)=destdx(:,i)'*destdy(:,i);
end

CCEP = sum(Sy)/sum(Sx);
CCEP_BIAS = CCEP-beta0;

CCEP_RMSE = sqrt(CCEP_BIAS^2+var(CCEMG));

memest_ccemg=zeros(Nr*2,1);
for i=1:Nr*2
memest_ccemg(i)=fminbnd(@(d)(1/T)*sum(fracdiff((yproj(:,i)-CCEMG*xproj(:,i)),d).^2), 0, 1.5);
end
mem_ccemg_bias = mean(memest_ccemg)-dU;

memest_ccep=zeros(Nr*2,1);
for i=1:Nr*2
memest_ccep(i)=fminbnd(@(d)(1/T)*sum(fracdiff((yproj(:,i)-CCEP*xproj(:,i)),d).^2), 0, 1.5);
end
mem_ccep_bias = mean(memest_ccep)-dU;
